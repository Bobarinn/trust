package com.mycompany.trust

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
