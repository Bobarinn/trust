import 'dart:convert';
import 'dart:typed_data';

import '/flutter_flow/flutter_flow_util.dart';
import 'api_manager.dart';

export 'api_manager.dart' show ApiCallResponse;

const _kPrivateApiFunctionName = 'ffPrivateApiCall';

class SignupCall {
  static Future<ApiCallResponse> call({
    String? name = '',
    String? email = '',
    String? password = '',
  }) async {
    final ffApiRequestBody = '''
{
  "name": "${name}",
  "email": "${email}",
  "password": "${password}"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Signup',
      apiUrl: 'https://x8ki-letl-twmt.n7.xano.io/api:AsOn-YTT/auth/signup',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  static String? authToken(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.authToken''',
      ));
}

class LoginCall {
  static Future<ApiCallResponse> call({
    String? email = '',
    String? password = '',
  }) async {
    final ffApiRequestBody = '''
{
  "email": "${email}",
  "password": "${password}"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Login',
      apiUrl: 'https://x8ki-letl-twmt.n7.xano.io/api:AsOn-YTT/auth/login',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  static String? authToken(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.authToken''',
      ));
}

class GetBusinessesCall {
  static Future<ApiCallResponse> call() async {
    return ApiManager.instance.makeApiCall(
      callName: 'Get Businesses',
      apiUrl: 'https://x8ki-letl-twmt.n7.xano.io/api:AsOn-YTT/vendor',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  static List<double>? ratingValue(dynamic response) => (getJsonField(
        response,
        r'''$.vendor1[:].rating[:].ratingsValue''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<double>(x))
          .withoutNulls
          .toList();
  static List<String>? name(dynamic response) => (getJsonField(
        response,
        r'''$.vendor1[:].name''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? ig(dynamic response) => (getJsonField(
        response,
        r'''$.vendor1[:].instagram''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? phone(dynamic response) => (getJsonField(
        response,
        r'''$.vendor1[:].phone''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? website(dynamic response) => (getJsonField(
        response,
        r'''$.vendor1[:].website''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? logo(dynamic response) => (getJsonField(
        response,
        r'''$.vendor1[:].logo.url''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<int>? ratingVendor(dynamic response) => (getJsonField(
        response,
        r'''$.vendor1[:].rating[:].ratingsVendorId''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<int>(x))
          .withoutNulls
          .toList();
  static List<int>? vendorId(dynamic response) => (getJsonField(
        response,
        r'''$.vendor1[:].id''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<int>(x))
          .withoutNulls
          .toList();
  static List<int>? ratingCount(dynamic response) => (getJsonField(
        response,
        r'''$.vendor1[:].rating[:].ratingcount''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<int>(x))
          .withoutNulls
          .toList();
  static List? vendorlist(dynamic response) => getJsonField(
        response,
        r'''$.vendor1''',
        true,
      ) as List?;
  static List? ratinglist(dynamic response) => getJsonField(
        response,
        r'''$.vendor1[:].rating''',
        true,
      ) as List?;
}

class GetACompanyCall {
  static Future<ApiCallResponse> call({
    String? vendorId = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'Get a company',
      apiUrl:
          'https://x8ki-letl-twmt.n7.xano.io/api:AsOn-YTT/vendor/${vendorId}',
      callType: ApiCallType.GET,
      headers: {},
      params: {
        'vendor_id': vendorId,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  static int? vendorid(dynamic response) => castToType<int>(getJsonField(
        response,
        r'''$.id''',
      ));
  static String? name(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.name''',
      ));
  static String? ig(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.instagram''',
      ));
  static String? phone(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.phone''',
      ));
  static String? website(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.website''',
      ));
  static String? logo(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.logo.url''',
      ));
  static int? creator(dynamic response) => castToType<int>(getJsonField(
        response,
        r'''$.created_by''',
      ));
  static int? admin(dynamic response) => castToType<int>(getJsonField(
        response,
        r'''$.admin_id''',
      ));
  static int? createdat(dynamic response) => castToType<int>(getJsonField(
        response,
        r'''$.created_at''',
      ));
  static int? totalratings(dynamic response) => castToType<int>(getJsonField(
        response,
        r'''$.countratings''',
      ));
  static List? groupedratings(dynamic response) => getJsonField(
        response,
        r'''$.ratingsgroupedsorteddes''',
        true,
      ) as List?;
  static List? groupedratingsvalue(dynamic response) => getJsonField(
        response,
        r'''$.ratingsgroupedsorteddes[:].value''',
        true,
      ) as List?;
  static List? groupedratingscount(dynamic response) => getJsonField(
        response,
        r'''$.ratingsgroupedsorteddes[:].count''',
        true,
      ) as List?;
}

class GetCompanyRatingCall {
  static Future<ApiCallResponse> call({
    String? companyId = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'Get company rating',
      apiUrl:
          'https://x8ki-letl-twmt.n7.xano.io/api:AsOn-YTT/companyratings/${companyId}',
      callType: ApiCallType.GET,
      headers: {},
      params: {
        'company_id': companyId,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  static List<int>? id(dynamic response) => (getJsonField(
        response,
        r'''$[:].id''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<int>(x))
          .withoutNulls
          .toList();
  static List<int>? createdat(dynamic response) => (getJsonField(
        response,
        r'''$[:].created_at''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<int>(x))
          .withoutNulls
          .toList();
  static List<int>? value(dynamic response) => (getJsonField(
        response,
        r'''$[:].value''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<int>(x))
          .withoutNulls
          .toList();
  static List<int>? uid(dynamic response) => (getJsonField(
        response,
        r'''$[:].user_id''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<int>(x))
          .withoutNulls
          .toList();
  static List<int>? companyid(dynamic response) => (getJsonField(
        response,
        r'''$[:].vendor_id''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<int>(x))
          .withoutNulls
          .toList();
  static List<String>? description(dynamic response) => (getJsonField(
        response,
        r'''$[:].description''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? title(dynamic response) => (getJsonField(
        response,
        r'''$[:].title''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List? imagesjson(dynamic response) => getJsonField(
        response,
        r'''$[:].images''',
        true,
      ) as List?;
  static List<String>? imageurl(dynamic response) => (getJsonField(
        response,
        r'''$[:].images[:].url''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List? userjson(dynamic response) => getJsonField(
        response,
        r'''$[:].user''',
        true,
      ) as List?;
  static List<String>? username(dynamic response) => (getJsonField(
        response,
        r'''$[:].user.name''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? useremail(dynamic response) => (getJsonField(
        response,
        r'''$[:].user.email''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? userlocation(dynamic response) => (getJsonField(
        response,
        r'''$[:].user.location''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<int>? userid(dynamic response) => (getJsonField(
        response,
        r'''$[:].user.id''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<int>(x))
          .withoutNulls
          .toList();
  static List? userpic(dynamic response) => getJsonField(
        response,
        r'''$[:].user.profilepic''',
        true,
      ) as List?;
}

class GetAllRatingsCall {
  static Future<ApiCallResponse> call() async {
    return ApiManager.instance.makeApiCall(
      callName: 'Get all ratings',
      apiUrl: 'https://x8ki-letl-twmt.n7.xano.io/api:AsOn-YTT/ratings',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  static List<int>? id(dynamic response) => (getJsonField(
        response,
        r'''$[:].id''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<int>(x))
          .withoutNulls
          .toList();
  static List<int>? createdat(dynamic response) => (getJsonField(
        response,
        r'''$[:].created_at''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<int>(x))
          .withoutNulls
          .toList();
  static List<int>? value(dynamic response) => (getJsonField(
        response,
        r'''$[:].value''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<int>(x))
          .withoutNulls
          .toList();
  static List<int>? user(dynamic response) => (getJsonField(
        response,
        r'''$[:].user_id''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<int>(x))
          .withoutNulls
          .toList();
  static List<int>? vendor(dynamic response) => (getJsonField(
        response,
        r'''$[:].vendor_id''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<int>(x))
          .withoutNulls
          .toList();
  static List<String>? description(dynamic response) => (getJsonField(
        response,
        r'''$[:].description''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List<String>? title(dynamic response) => (getJsonField(
        response,
        r'''$[:].title''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static List? images(dynamic response) => getJsonField(
        response,
        r'''$[:].images''',
        true,
      ) as List?;
  static List<String>? imageurl(dynamic response) => (getJsonField(
        response,
        r'''$[:].images[:].url''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
}

class ApiPagingParams {
  int nextPageNumber = 0;
  int numItems = 0;
  dynamic lastResponse;

  ApiPagingParams({
    required this.nextPageNumber,
    required this.numItems,
    required this.lastResponse,
  });

  @override
  String toString() =>
      'PagingParams(nextPageNumber: $nextPageNumber, numItems: $numItems, lastResponse: $lastResponse,)';
}

String _serializeList(List? list) {
  list ??= <String>[];
  try {
    return json.encode(list);
  } catch (_) {
    return '[]';
  }
}

String _serializeJson(dynamic jsonVar, [bool isList = false]) {
  jsonVar ??= (isList ? [] : {});
  try {
    return json.encode(jsonVar);
  } catch (_) {
    return isList ? '[]' : '{}';
  }
}
