import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/custom_functions.dart' as functions;
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:percent_indicator/percent_indicator.dart';
import 'package:provider/provider.dart';
import 'company_page_model.dart';
export 'company_page_model.dart';

class CompanyPageWidget extends StatefulWidget {
  const CompanyPageWidget({
    super.key,
    required this.companyId,
    required this.companyDetails,
  });

  final String? companyId;
  final dynamic companyDetails;

  @override
  State<CompanyPageWidget> createState() => _CompanyPageWidgetState();
}

class _CompanyPageWidgetState extends State<CompanyPageWidget> {
  late CompanyPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => CompanyPageModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (isiOS) {
      SystemChrome.setSystemUIOverlayStyle(
        SystemUiOverlayStyle(
          statusBarBrightness: Theme.of(context).brightness,
          systemStatusBarContrastEnforced: true,
        ),
      );
    }

    context.watch<FFAppState>();

    return FutureBuilder<ApiCallResponse>(
      future: GetCompanyRatingCall.call(
        companyId: widget.companyId,
      ),
      builder: (context, snapshot) {
        // Customize what your widget looks like when it's loading.
        if (!snapshot.hasData) {
          return Scaffold(
            backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
            body: Center(
              child: SizedBox(
                width: 50.0,
                height: 50.0,
                child: CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(
                    FlutterFlowTheme.of(context).primary,
                  ),
                ),
              ),
            ),
          );
        }
        final companyPageGetCompanyRatingResponse = snapshot.data!;
        return GestureDetector(
          onTap: () => _model.unfocusNode.canRequestFocus
              ? FocusScope.of(context).requestFocus(_model.unfocusNode)
              : FocusScope.of(context).unfocus(),
          child: Scaffold(
            key: scaffoldKey,
            backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
            appBar: AppBar(
              backgroundColor: FlutterFlowTheme.of(context).primary,
              automaticallyImplyLeading: true,
              title: Text(
                getJsonField(
                  widget.companyDetails,
                  r'''$.name''',
                ).toString(),
                style: FlutterFlowTheme.of(context).headlineMedium.override(
                      fontFamily: 'Outfit',
                      color: Colors.white,
                      fontSize: 24.0,
                      fontWeight: FontWeight.w600,
                    ),
              ),
              actions: [],
              centerTitle: false,
              elevation: 2.0,
            ),
            body: SafeArea(
              top: true,
              child: SingleChildScrollView(
                primary: false,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 16.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8.0),
                            child: Image.network(
                              getJsonField(
                                widget.companyDetails,
                                r'''$.logo.url''',
                              ).toString(),
                              width: 72.0,
                              height: 72.0,
                              fit: BoxFit.cover,
                            ),
                          ),
                          Expanded(
                            child: Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 1.0, 0.0, 0.0),
                              child: Column(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    getJsonField(
                                      widget.companyDetails,
                                      r'''$.name''',
                                    ).toString(),
                                    style: FlutterFlowTheme.of(context)
                                        .bodyLarge
                                        .override(
                                          fontFamily: 'Readex Pro',
                                          fontWeight: FontWeight.w500,
                                        ),
                                  ),
                                  Row(
                                    mainAxisSize: MainAxisSize.max,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      FaIcon(
                                        FontAwesomeIcons.globe,
                                        color: FlutterFlowTheme.of(context)
                                            .secondaryText,
                                        size: 14.0,
                                      ),
                                      Text(
                                        functions.normalizeURL(getJsonField(
                                          widget.companyDetails,
                                          r'''$.website''',
                                        ).toString())!,
                                        style: FlutterFlowTheme.of(context)
                                            .labelSmall,
                                      ),
                                    ].divide(SizedBox(width: 8.0)),
                                  ),
                                  Row(
                                    mainAxisSize: MainAxisSize.max,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      FaIcon(
                                        FontAwesomeIcons.instagram,
                                        color: FlutterFlowTheme.of(context)
                                            .secondaryText,
                                        size: 16.0,
                                      ),
                                      AutoSizeText(
                                        getJsonField(
                                          widget.companyDetails,
                                          r'''$.instagram''',
                                        ).toString().maybeHandleOverflow(
                                              maxChars: 34,
                                              replacement: '…',
                                            ),
                                        textAlign: TextAlign.start,
                                        style: FlutterFlowTheme.of(context)
                                            .labelSmall,
                                      ),
                                    ].divide(SizedBox(width: 8.0)),
                                  ),
                                ].divide(SizedBox(height: 8.0)),
                              ),
                            ),
                          ),
                        ].divide(SizedBox(width: 16.0)),
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                      child: Material(
                        color: Colors.transparent,
                        elevation: 1.0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12.0),
                        ),
                        child: Container(
                          width: 440.0,
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context).babyPowder,
                            borderRadius: BorderRadius.circular(12.0),
                            border: Border.all(
                              color: Color(0xFFE7E7E7),
                              width: 1.0,
                            ),
                          ),
                          child: Padding(
                            padding: EdgeInsets.all(16.0),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Column(
                                  mainAxisSize: MainAxisSize.max,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      formatNumber(
                                        functions.changeRatingValueToDouble(
                                            getJsonField(
                                          widget.companyDetails,
                                          r'''$.rating[:].ratingsValue''',
                                        )),
                                        formatType: FormatType.custom,
                                        format: '0.0',
                                        locale: 'en_US',
                                      ),
                                      style: FlutterFlowTheme.of(context)
                                          .displaySmall,
                                    ),
                                    Text(
                                      valueOrDefault<String>(
                                        functions.classifyRating(
                                            functions.changeRatingValueToDouble(
                                                getJsonField(
                                          widget.companyDetails,
                                          r'''$.rating[:].ratingsValue''',
                                        ))),
                                        'No Reviews Yet',
                                      ),
                                      style: FlutterFlowTheme.of(context)
                                          .titleLarge,
                                    ),
                                    RatingBarIndicator(
                                      itemBuilder: (context, index) => Icon(
                                        Icons.star_rounded,
                                        color: FlutterFlowTheme.of(context)
                                            .castletonGreen,
                                      ),
                                      direction: Axis.horizontal,
                                      rating:
                                          functions.changeRatingValueToDouble(
                                              getJsonField(
                                        widget.companyDetails,
                                        r'''$.rating[:].ratingsValue''',
                                      )),
                                      unratedColor: Color(0x7F84A298),
                                      itemCount: 5,
                                      itemSize: 24.0,
                                    ),
                                    Padding(
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          4.0, 0.0, 0.0, 0.0),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.max,
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: [
                                          Text(
                                            valueOrDefault<String>(
                                              GetCompanyRatingCall.value(
                                                companyPageGetCompanyRatingResponse
                                                    .jsonBody,
                                              )?.length?.toString(),
                                              '0',
                                            ),
                                            style: FlutterFlowTheme.of(context)
                                                .bodyLarge,
                                          ),
                                          Padding(
                                            padding:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    4.0, 0.0, 0.0, 0.0),
                                            child: Text(
                                              'reviews',
                                              style:
                                                  FlutterFlowTheme.of(context)
                                                      .bodyLarge,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                                Expanded(
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Column(
                                        mainAxisSize: MainAxisSize.min,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Row(
                                            mainAxisSize: MainAxisSize.max,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              Text(
                                                '5-star',
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .bodyLarge,
                                              ),
                                              Expanded(
                                                child: Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          8.0, 0.0, 0.0, 0.0),
                                                  child: LinearPercentIndicator(
                                                    percent: functions
                                                        .dividetwonumbers(
                                                            valueOrDefault<int>(
                                                              GetCompanyRatingCall
                                                                      .value(
                                                                companyPageGetCompanyRatingResponse
                                                                    .jsonBody,
                                                              )
                                                                  ?.where((e) =>
                                                                      e == (5))
                                                                  .toList()
                                                                  ?.length,
                                                              0,
                                                            ),
                                                            valueOrDefault<int>(
                                                              GetCompanyRatingCall
                                                                  .value(
                                                                companyPageGetCompanyRatingResponse
                                                                    .jsonBody,
                                                              )?.length,
                                                              0,
                                                            )),
                                                    width: 120.0,
                                                    lineHeight: 6.0,
                                                    animation: true,
                                                    animateFromLastPercent:
                                                        true,
                                                    progressColor:
                                                        FlutterFlowTheme.of(
                                                                context)
                                                            .primaryText,
                                                    backgroundColor:
                                                        Color(0x4C14181B),
                                                    barRadius:
                                                        Radius.circular(5.0),
                                                    padding: EdgeInsets.zero,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                          Row(
                                            mainAxisSize: MainAxisSize.max,
                                            children: [
                                              Text(
                                                '4-star',
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .bodyLarge,
                                              ),
                                              Flexible(
                                                child: Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          8.0, 0.0, 0.0, 0.0),
                                                  child: LinearPercentIndicator(
                                                    percent: functions
                                                        .dividetwonumbers(
                                                            valueOrDefault<int>(
                                                              GetCompanyRatingCall
                                                                      .value(
                                                                companyPageGetCompanyRatingResponse
                                                                    .jsonBody,
                                                              )
                                                                  ?.where((e) =>
                                                                      e == (4))
                                                                  .toList()
                                                                  ?.length,
                                                              0,
                                                            ),
                                                            valueOrDefault<int>(
                                                              GetCompanyRatingCall
                                                                  .value(
                                                                companyPageGetCompanyRatingResponse
                                                                    .jsonBody,
                                                              )?.length,
                                                              0,
                                                            )),
                                                    width: 120.0,
                                                    lineHeight: 6.0,
                                                    animation: true,
                                                    animateFromLastPercent:
                                                        true,
                                                    progressColor:
                                                        FlutterFlowTheme.of(
                                                                context)
                                                            .primaryText,
                                                    backgroundColor:
                                                        Color(0x4C14181B),
                                                    barRadius:
                                                        Radius.circular(5.0),
                                                    padding: EdgeInsets.zero,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                          Row(
                                            mainAxisSize: MainAxisSize.max,
                                            children: [
                                              Text(
                                                '3-star',
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .bodyLarge,
                                              ),
                                              Expanded(
                                                child: Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          8.0, 0.0, 0.0, 0.0),
                                                  child: LinearPercentIndicator(
                                                    percent: functions
                                                        .dividetwonumbers(
                                                            valueOrDefault<int>(
                                                              GetCompanyRatingCall
                                                                      .value(
                                                                companyPageGetCompanyRatingResponse
                                                                    .jsonBody,
                                                              )
                                                                  ?.where((e) =>
                                                                      e == (3))
                                                                  .toList()
                                                                  ?.length,
                                                              0,
                                                            ),
                                                            valueOrDefault<int>(
                                                              GetCompanyRatingCall
                                                                  .value(
                                                                companyPageGetCompanyRatingResponse
                                                                    .jsonBody,
                                                              )?.length,
                                                              0,
                                                            )),
                                                    width: 120.0,
                                                    lineHeight: 6.0,
                                                    animation: true,
                                                    animateFromLastPercent:
                                                        true,
                                                    progressColor:
                                                        FlutterFlowTheme.of(
                                                                context)
                                                            .primaryText,
                                                    backgroundColor:
                                                        Color(0x4C14181B),
                                                    barRadius:
                                                        Radius.circular(5.0),
                                                    padding: EdgeInsets.zero,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                          Row(
                                            mainAxisSize: MainAxisSize.max,
                                            children: [
                                              Text(
                                                '2-star',
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .bodyLarge,
                                              ),
                                              Expanded(
                                                child: Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          8.0, 0.0, 0.0, 0.0),
                                                  child: LinearPercentIndicator(
                                                    percent: functions
                                                        .dividetwonumbers(
                                                            valueOrDefault<int>(
                                                              GetCompanyRatingCall
                                                                      .value(
                                                                companyPageGetCompanyRatingResponse
                                                                    .jsonBody,
                                                              )
                                                                  ?.where((e) =>
                                                                      e == (2))
                                                                  .toList()
                                                                  ?.length,
                                                              0,
                                                            ),
                                                            valueOrDefault<int>(
                                                              GetCompanyRatingCall
                                                                  .value(
                                                                companyPageGetCompanyRatingResponse
                                                                    .jsonBody,
                                                              )?.length,
                                                              0,
                                                            )),
                                                    width: 120.0,
                                                    lineHeight: 6.0,
                                                    animation: true,
                                                    animateFromLastPercent:
                                                        true,
                                                    progressColor:
                                                        FlutterFlowTheme.of(
                                                                context)
                                                            .primaryText,
                                                    backgroundColor:
                                                        Color(0x4C14181B),
                                                    barRadius:
                                                        Radius.circular(5.0),
                                                    padding: EdgeInsets.zero,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                          Row(
                                            mainAxisSize: MainAxisSize.max,
                                            children: [
                                              Text(
                                                '1-star',
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .bodyLarge,
                                              ),
                                              Expanded(
                                                child: Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          8.0, 0.0, 0.0, 0.0),
                                                  child: LinearPercentIndicator(
                                                    percent: functions
                                                        .dividetwonumbers(
                                                            valueOrDefault<int>(
                                                              GetCompanyRatingCall
                                                                      .value(
                                                                companyPageGetCompanyRatingResponse
                                                                    .jsonBody,
                                                              )
                                                                  ?.where((e) =>
                                                                      e == (1))
                                                                  .toList()
                                                                  ?.length,
                                                              0,
                                                            ),
                                                            valueOrDefault<int>(
                                                              GetCompanyRatingCall
                                                                  .value(
                                                                companyPageGetCompanyRatingResponse
                                                                    .jsonBody,
                                                              )?.length,
                                                              0,
                                                            )),
                                                    width: 120.0,
                                                    lineHeight: 6.0,
                                                    animation: true,
                                                    animateFromLastPercent:
                                                        true,
                                                    progressColor:
                                                        FlutterFlowTheme.of(
                                                                context)
                                                            .primaryText,
                                                    backgroundColor:
                                                        Color(0x4C14181B),
                                                    barRadius:
                                                        Radius.circular(5.0),
                                                    padding: EdgeInsets.zero,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ].divide(SizedBox(height: 8.0)),
                                      ),
                                    ],
                                  ),
                                ),
                              ].divide(SizedBox(width: 16.0)),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                      child: Container(
                        width: MediaQuery.sizeOf(context).width * 1.0,
                        decoration: BoxDecoration(),
                        child: Text(
                          'Latest Reviews',
                          style: FlutterFlowTheme.of(context)
                              .headlineLarge
                              .override(
                                fontFamily: 'Outfit',
                                fontSize: 28.0,
                              ),
                        ),
                      ),
                    ),
                    Builder(
                      builder: (context) {
                        final companyRating = getJsonField(
                          companyPageGetCompanyRatingResponse.jsonBody,
                          r'''$''',
                        ).toList();
                        return ListView.separated(
                          padding: EdgeInsets.zero,
                          primary: false,
                          shrinkWrap: true,
                          scrollDirection: Axis.vertical,
                          itemCount: companyRating.length,
                          separatorBuilder: (_, __) => SizedBox(height: 16.0),
                          itemBuilder: (context, companyRatingIndex) {
                            final companyRatingItem =
                                companyRating[companyRatingIndex];
                            return Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  16.0, 0.0, 16.0, 0.0),
                              child: Material(
                                color: Colors.transparent,
                                elevation: 1.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12.0),
                                ),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color:
                                        FlutterFlowTheme.of(context).babyPowder,
                                    borderRadius: BorderRadius.circular(12.0),
                                    border: Border.all(
                                      color: Color(0xFFE7E7E7),
                                      width: 1.0,
                                    ),
                                  ),
                                  child: Padding(
                                    padding: EdgeInsets.all(16.0),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.max,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          mainAxisSize: MainAxisSize.max,
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(44.0),
                                              child: Image.network(
                                                getJsonField(
                                                          companyRatingItem,
                                                          r'''$.user.profilepic.url''',
                                                        ) !=
                                                        null
                                                    ? getJsonField(
                                                        companyRatingItem,
                                                        r'''$.user.profilepic.url''',
                                                      ).toString()
                                                    : 'https://images.unsplash.com/photo-1618828665347-d870c38c95c7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w0NTYyMDF8MHwxfHNlYXJjaHwyfHxuaWdlcmlhfGVufDB8fHx8MTcwNjY1OTM5NHww&ixlib=rb-4.0.3&q=80&w=400',
                                                width: 44.0,
                                                height: 44.0,
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                            Expanded(
                                              child: Align(
                                                alignment: AlignmentDirectional(
                                                    -1.0, -1.0),
                                                child: Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          0.0, 1.0, 0.0, 0.0),
                                                  child: Column(
                                                    mainAxisSize:
                                                        MainAxisSize.max,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      Padding(
                                                        padding:
                                                            EdgeInsetsDirectional
                                                                .fromSTEB(
                                                                    4.0,
                                                                    0.0,
                                                                    0.0,
                                                                    0.0),
                                                        child: Text(
                                                          getJsonField(
                                                            companyRatingItem,
                                                            r'''$.user.name''',
                                                          ).toString(),
                                                          style: FlutterFlowTheme
                                                                  .of(context)
                                                              .bodyLarge
                                                              .override(
                                                                fontFamily:
                                                                    'Readex Pro',
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w500,
                                                              ),
                                                        ),
                                                      ),
                                                      Row(
                                                        mainAxisSize:
                                                            MainAxisSize.max,
                                                        children: [
                                                          RatingBarIndicator(
                                                            itemBuilder:
                                                                (context,
                                                                        index) =>
                                                                    Icon(
                                                              Icons
                                                                  .star_rounded,
                                                              color: FlutterFlowTheme
                                                                      .of(context)
                                                                  .castletonGreen,
                                                            ),
                                                            direction:
                                                                Axis.horizontal,
                                                            rating:
                                                                getJsonField(
                                                              companyRatingItem,
                                                              r'''$.value''',
                                                            ),
                                                            unratedColor: Color(
                                                                0x7F84A298),
                                                            itemCount: 5,
                                                            itemSize: 16.0,
                                                          ),
                                                        ],
                                                      ),
                                                    ].divide(
                                                        SizedBox(height: 4.0)),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Text(
                                              dateTimeFormat(
                                                  'relative',
                                                  DateTime
                                                      .fromMillisecondsSinceEpoch(
                                                          getJsonField(
                                                    companyRatingItem,
                                                    r'''$.created_at''',
                                                  ))),
                                              style:
                                                  FlutterFlowTheme.of(context)
                                                      .labelSmall,
                                            ),
                                          ].divide(SizedBox(width: 8.0)),
                                        ),
                                        Divider(
                                          thickness: 1.0,
                                          color: Color(0xFFD3D3D3),
                                        ),
                                        Text(
                                          getJsonField(
                                            companyRatingItem,
                                            r'''$.title''',
                                          ).toString(),
                                          style: FlutterFlowTheme.of(context)
                                              .titleLarge
                                              .override(
                                                fontFamily: 'Outfit',
                                                fontSize: 18.0,
                                                fontWeight: FontWeight.w600,
                                              ),
                                        ),
                                        Text(
                                          getJsonField(
                                            companyRatingItem,
                                            r'''$.description''',
                                          ).toString(),
                                          style: FlutterFlowTheme.of(context)
                                              .bodyLarge,
                                        ),
                                      ].divide(SizedBox(height: 4.0)),
                                    ),
                                  ),
                                ),
                              ),
                            );
                          },
                        );
                      },
                    ),
                  ]
                      .divide(SizedBox(height: 16.0))
                      .addToStart(SizedBox(height: 16.0))
                      .addToEnd(SizedBox(height: 16.0)),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
