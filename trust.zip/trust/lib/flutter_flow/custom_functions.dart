import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';

double changeRatingValueToDouble(double? ratingValue) {
  // Convert ratingValue to one decimal place,if null return 0.0
  if (ratingValue != null) {
    return double.parse(ratingValue.toStringAsFixed(1));
  } else {
    return 0.0;
  }
}

String? normalizeURL(String? website) {
  // convert URL to the format "openai.com"  removing the https and / at the back
  if (website == null) {
    return null;
  }
  final uri = Uri.parse(website);
  final host = uri.host;
  final parts = host.split('.');
  if (parts.length > 2) {
    return parts.sublist(1).join('.');
  } else {
    return host;
  }
}

double dividetwonumbers(
  int? value1,
  int? value2,
) {
  // divide value1 by value2 provide answer in two decimal places
  if (value1 == null || value2 == null || value2 == 0) {
    return 0.0;
  }
  final result = value1 / value2;
  return double.parse(result.toStringAsFixed(2));
}

String? classifyRating(double? value) {
  // Take value and return Excellent if between 4 and 5, create for other ranges
  if (value == null) {
    return null;
  } else if (value >= 4.0 && value <= 5.0) {
    return 'Excellent';
  } else if (value >= 3.0 && value < 4.0) {
    return 'Good';
  } else if (value >= 2.0 && value < 3.0) {
    return 'Fair';
  } else if (value >= 1.0 && value < 2.0) {
    return 'Poor';
  } else if (value == 0.0) {
    return 'No Reveiws';
  } else {
    return null;
  }
}
